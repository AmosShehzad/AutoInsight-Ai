import json
import time
from langchain_core.prompts import ChatPromptTemplate
from utils.llm_factory import get_llm
from app.config import config
from app.schemas.state import GraphState
from app.schemas.narrative import ExecutiveNarrative
from app.node_wrapper import node_error_boundary
from app.logger import get_logger

logger = get_logger(__name__)


class NarrativeAgentError(Exception):
    pass


NARRATIVE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", (
        "You are a senior management consultant writing for a business owner who is NOT technical. "
        "You will be given statistics, correlations, and insights already computed from a real dataset.\n\n"
        "Rules:\n"
        "- NEVER invent a number that isn't in the data you were given.\n"
        "- Write like a consultant telling a story, not a scientist reporting results.\n"
        "- Every claim must be traceable to a real number you were given.\n"
        "- Do not mention forecasts, predictions, or future performance — you only have historical data.\n"
        "- Column intelligence: only cover the TOP 5 most important numeric columns, not every column.\n"
        "- Confidence ratings must reflect real signal strength: a correlation above 0.7 is High confidence, "
        "0.4-0.7 is Medium, below 0.4 is Low.\n"
        "You MUST respond with a valid JSON object matching this shape:\n"
        '{{"business_story": "...", "column_intelligence": [...], "opportunities": [...], "risks": [...]}}\n'
        "Return ONLY the JSON object, no explanation, no markdown fences."
    )),
    ("human", (
        "Profile:\n{profile}\n\n"
        "Statistics:\n{statistics}\n\n"
        "Existing insights:\n{insights}\n\n"
        "Write the executive narrative now, as JSON."
    )),
])


def _build_chain(temperature: float = 0.3):
    llm = get_llm(temperature=temperature)
    return NARRATIVE_PROMPT | llm.with_structured_output(ExecutiveNarrative, method="json_mode")


@node_error_boundary("narrative_agent")
def narrative_agent_node(state: GraphState) -> dict:
    profile = state.get("profile")
    statistics = state.get("statistics")
    insights = state.get("insights")

    if not profile or not statistics:
        raise NarrativeAgentError("Narrative Agent needs 'profile' and 'statistics' in state.")

    chain = _build_chain()
    inputs = {
        "profile": json.dumps({k: v for k, v in profile.items() if k != "categorical_stats"}, indent=2)[:3000],
        "statistics": json.dumps(statistics.get("results", {}), indent=2)[:4000],
        "insights": json.dumps(insights or [], indent=2),
    }

    last_error = None
    for attempt in range(1, config.MAX_LLM_RETRIES + 2):
        try:
            result: ExecutiveNarrative = chain.invoke(inputs)
            logger.info(f"Narrative Agent completed on attempt {attempt}")
            return {"narrative": result.model_dump()}
        except Exception as e:
            last_error = e
            if attempt <= config.MAX_LLM_RETRIES:
                time.sleep(1.5 * attempt)
                continue

    raise NarrativeAgentError(f"Narrative Agent failed after retries: {last_error}")